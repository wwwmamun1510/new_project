<?php
session_start();
require 'db.php';
$email = $_POST['email'];
$password = $_POST['password'];

$select_email = "SELECT COUNT(*) as email_exist  FROM users WHERE email= '$email'";
$select_email_result = mysqli_query($db_connect, $select_email);
$after_assoc = mysqli_fetch_assoc($select_email_result);

if($after_assoc['email_exist'] == 1){
    
   $select_email2 = "SELECT * FROM users WHERE email='$email'";
   $select_email_result2 = mysqli_query($db_connect, $select_email2);
   $after_assoc2 = mysqli_fetch_assoc($select_email_result2);


        if(password_verify($password, $after_assoc2['password'])) {


            echo 'ok...done';

        }
        else {

            echo 'no..never';
        }


      }

   else {

   $_SESSION['email_exist'] = 'Invalid Email';
   header('location:login.php');
}



?>

