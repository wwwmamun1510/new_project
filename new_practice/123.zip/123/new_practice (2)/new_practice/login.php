
<?php
session_start();
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
   <section>
       <div class="container">
           <div class="row">
            <div class="col-lg-6 m-auto">
             <?php if (isset( $_SESSION['success'] )){ ?>
             <div class="alert alert-success">
                 <?=$_SESSION['success']?>
               </div>
               <?php } unset($_SESSION['success'] )?>
              <div class="card">
              <div class="card-header">
              <h3>Login From</h3>
              </div>
               <div class="card-body">
                 <form action="login_post.php" method="POST">
                 <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Email</label>
                <input type="email" name="email"  class="form-control">
                <?php if(isset($_SESSION ['email_exist'])){ ?>
                    <div class = "alert alert-danger mt-2">
                        <?=$_SESSION ['email_exist'];?>
                 </div>
                 <?php } unset($_SESSION['email_exist']) ?>
                 </div>
                 <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Password</label>
                <input type="password" name="password"  class="form-control">
                <?php if(isset($_SESSION ['errors']['password'])){ ?>
                <div class = "alert alert-danger">
                 <?=$_SESSION['errors'] ['password'];?>
                 </div>
                 <?php } unset($_SESSION['errors'] ['password']) ?>
                 </div>
                 <button type="submit" class="btn btn-primary">Login</button>
                 </form>
            </div>
       </div>
   </section>
  </body>
</html>

