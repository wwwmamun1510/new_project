<?php

session_start();
require '../db.php';
$id = $_GET['id'];
$select_users = "SELECT * FROM users WHERE id = $id";
$select_users_result = mysqli_query($db_connect, $select_users);
$after_assoc = mysqli_fetch_assoc($select_users_result);

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
   <section>
       <div class="container">
           <div class="row">
            <div class="col-lg-6 m-auto">
             <div class="card">
            <div class="card-header">
            <h3>Edit TEAM-Alpha Information</h3>
            </div>
            <?php if (isset( $_SESSION['update_users'] )){ ?>
             <div class="alert alert-success">
                 <?=$_SESSION['update_users']?>
               </div>
               <?php } unset($_SESSION['update_users'])?>
            <div class="card-body">
                 <form action="update.php" method="POST" enctype="multipart/form-data">
                 <div class="mb-3">
                <input type="hidden" name="id" value="<?=$after_assoc['id']?>">
                <label for="exampleInputEmail1" class="form-label">Name</label>
                <input value="<?=$after_assoc['name']?>" type="text" name="name" class="form-control">
                 <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Email</label>
                 <input value="<?=$after_assoc['email']?>" type="email" name="email"  class="form-control">
                 </div>
                 <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Password</label>
                <input value="<?=$after_assoc['Password']?>" type="password" name="password"  class="form-control">
                 </div>
                 <div class="mb-3">
                    <img class="w-50" src ="../uploads/users/<?=$after_assoc['profile_photo']?>" alt="">
                </div>
                <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">profile photo</label>
                <input type="file" name="profile_photo"  class="form-control">
                 </div>
                  <?php if (isset( $_SESSION['extension'] )){ ?>
             <div class="alert alert-success">
                 <?=$_SESSION['extension']?>
               </div>
               <?php } unset($_SESSION['extension'])?>

               <?php if (isset($_SESSION['file_size'] )){ ?>
             <div class="alert alert-success">
                 <?=$_SESSION['file_size']?>
               </div>
               <?php } unset($_SESSION['file_size'])?>

                <button type="submit" class="btn btn-primary">Submit</button>
                 </form>
            </div>
            </div>
   </section>
  </body>
</html>

