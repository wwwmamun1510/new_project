<?php
session_start();
if(!isset( $_SESSION['login_complete'] )){

  header('location:../login.php');
}



require '../db.php';

$select_users = "SELECT * FROM users WHERE status=0";
$select_users_result = mysqli_query($db_connect, $select_users);

$select_trash_users = "SELECT * FROM users WHERE status=1";
$select_trash_users_result = mysqli_query($db_connect, $select_trash_users);

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
     <body>
        <section>
             <div class="container">
                  <div class="row">
                      <div class="col-lg-10 m-auto">
                            <div class="card mt-5">
                                <div class="card-header bg-primary text-center">
                                    <h3 class="text-white">TEAM-Alpha</h3>
                                      </div>
                                      <?php if (isset( $_SESSION['delete_user'] )){ ?>
                                       <div class="alert alert-success mt-2">
                                       <?=$_SESSION['delete_user']?>
                                        </div>
                                        <?php } unset($_SESSION['delete_user'] )?>

                                        <?php if (isset( $_SESSION ['soft_del'] )){ ?>
                                       <div class="alert alert-success mt-2">
                                       <?=$_SESSION['soft_del']?>
                                        </div>
                                        <?php } unset($_SESSION['soft_del'] )?>

                                       <div class="card-body">
                                       <table class="table table-striped">
                                       <thead>
                                       <tr>
                                       <th scope="col">SL</th>
                                       <th scope="col">Name</th>
                                       <th scope="col">Email</th>
                                       <th scope="col">photo</th>
                                       <th scope="col">Created_At</th>
                                       <th scope="col">Action</th>
                                       </tr>
                                      </thead>
                                      <tbody>
                                          <?php foreach($select_users_result as $key=>$user){?>
                                    <tr>
                                      <th scope="row"><?= $key+1?></th>
                                     <td><?=$user['name']?></td>
                                      <td><?=$user['email']?></td>
                                      <td>
                                         <img width="150" src="../uploads/users/<?= $user['profile_photo']?>" alt="">
                                      </td>
                                      <td><?=$user['created_at']?></td>
                                      <td>
                                      <a href="view.php?id=<?= $user['id']?>" class="btn btn-secondary">View</a>
                                      <a href="edit.php?id=<?= $user['id']?>" class="btn btn-secondary">Edit</a>
                                     <a data-bs-toggle="modal" data-bs-target="#mod<?=$user['id']?>"   class="btn btn-danger">Delete</a>
                                      </td>
                                       </tr>
                                       <!-- Modal -->
                                       <div class="modal fade" id="mod<?=$user['id']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered">
                                                      <div class="modal-content">
                                                            <div class="modal-header">
                                                                 <h5 class="modal-title" id="exampleModalLabel">Are You Sure??????</h5>
                                                                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                   </div>
                                                               <div class="modal-body">
                                                              </div>
                                                    <div class="modal-footer">
                                         <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No...Not Yet</button>
                                     <a href="soft_delete.php?id=<?=$user['id']?>" class="btn btn-danger">Yes...Delete</a>         
                       <?php }?>
                </tbody>
             </table>
          </div>

          <div class="card mt-5">
                                <div class="card-header bg-secondary text-center">
                                    <h3 class="text-white">Trash</h3>
                                      </div>
                                      <?php if (isset( $_SESSION['delete_user'] )){ ?>
                                       <div class="alert alert-success mt-2">
                                       <?=$_SESSION['delete_user']?>
                                        </div>
                                        <?php } unset($_SESSION['delete_user'] )?>

                                        <?php if (isset( $_SESSION['restore'] )){ ?>
                                       <div class="alert alert-success mt-2">
                                       <?=$_SESSION['restore']?>
                                        </div>
                                        <?php } unset($_SESSION['restore'] )?>

                                       <div class="card-body">
                                       <table class="table table-striped">
                                       <thead>
                                       <tr>
                                       <th scope="col">SL</th>
                                       <th scope="col">Name</th>
                                       <th scope="col">Email</th>
                                       <th scope="col">photo</th>
                                       <th scope="col">Created_At</th>
                                       <th scope="col">Action</th>
                                       </tr>
                                      </thead>
                                      <tbody>
                                        <?php foreach($select_trash_users_result as $key=>$trash_user){?>
                                    <tr>
                                      <th scope="row"><?= $key+1?></th>
                                      <td><?= $trash_user['name']?></td>
                                      <td><?= $trash_user['email']?></td>
                                      <td> <img width="150" src="../uploads/users/<?= $trash_user['profile_photo']?>" alt=""></td>
                                      <td><?= $trash_user['created_at']?></td>
                                      <td>
                                      <a href="restore.php?id=<?= $trash_user['id']?>" class="btn       btn-secondary">Restore</a>
                                     <a data-bs-toggle="modal" data-bs-target="#mod<?=$trash_user['id']?>"   class="btn btn-danger">Delete</a>
                                      </td>
                                       </tr>
                                       <!-- Modal -->
                                       <div class="modal fade" id="mod<?=$trash_user['id']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered">
                                                      <div class="modal-content">
                                                            <div class="modal-header">
                                                                 <h5 class="modal-title" id="exampleModalLabel">Are You Sure??????</h5>
                                                                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                   </div>
                                                               <div class="modal-body">
                                                              </div>
                                                    <div class="modal-footer">
                                         <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No...Not Yet</button>
                                     <a href="delete.php?id=<?=$trash_user['id']?>" class="btn btn-danger">Yes...Delete</a>         
                                <?php } ?>
                            </tbody>
                         </table>
                       </div>
                     </div>
                   </div>
                 </div>
               </div>
           </section>

      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
  </html>
 