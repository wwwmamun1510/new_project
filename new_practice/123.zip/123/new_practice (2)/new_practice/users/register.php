<?php
session_start();
date_default_timezone_set('Asia/Dhaka');
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
   <section>
       <div class="container">
           <div class="row">
            <div class="col-lg-6 m-auto">
             <?php if (isset( $_SESSION['success'] )){ ?>
             <div class="alert alert-success">
                 <?=$_SESSION['success']?>
               </div>
               <?php } unset($_SESSION['success'] )?>
               
             <?php if (isset( $_SESSION['email_exist'] )){ ?>
             <div class="alert alert-warning">
                 <?=$_SESSION['email_exist'] ?>
               </div>
               <?php } unset($_SESSION['email_exist'] )?>
            <div class="card">
            <div class="card-header">
            <h3>Registration From</h3>
            </div>
            <div class="card-body">
                 <form action="post.php" method="POST" enctype="multipart/form-data">
                 <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Name</label>
                <input value="<?=(isset($_SESSION['name']))? $_SESSION['name']:''?>" type="text" name="name" class="form-control">
                <?php if(isset($_SESSION ['errors']['name'])){ ?>
                    <div class = "alert alert-danger">
                        <?=$_SESSION ['errors']['name'];?>
                 </div>
                 <?php } unset($_SESSION['errors']['name']) ?>
                 </div>
                 <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Email</label>
                <input value="<?=(isset($_SESSION['email']))? $_SESSION['email']:''?>" type="email" name="email"  class="form-control">
                <?php if(isset($_SESSION ['errors']['email'])){ ?>
                    <div class = "alert alert-danger">
                        <?=$_SESSION ['errors']['email'];?>
                 </div>
                 <?php } unset($_SESSION['errors']['email']) ?>
                 </div>
                 <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Password</label>
                <input value="<?=(isset($_SESSION['Password']))? $_SESSION['Password']:''?>" type="password" name="password"  class="form-control">
                <?php if(isset($_SESSION ['errors']['password'])){ ?>
                    <div class = "alert alert-danger">
                        <?=$_SESSION ['errors']['password'];?>
                 </div>
                 <?php } unset($_SESSION['errors']['password']) ?>
                 </div>

                 <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Profile Image</label>
                <input type="file" name="profile_image"  class="form-control">
                 </div>

                 <button type="submit" class="btn btn-primary">Submit</button>
                 </form>
            </div>
            </div>
   </section>
  </body>
</html>

<?php
unset($_SESSION['name']);
unset($_SESSION['email']);
unset($_SESSION['password']);

?>