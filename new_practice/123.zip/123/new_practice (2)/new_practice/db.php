
<?php

$hostname = 'localhost';
$username = 'root';
$hostpassword = '';
$dbname = 'modification';

$db_connect = mysqli_connect($hostname,  $username,  $hostpassword,  $dbname);

?>